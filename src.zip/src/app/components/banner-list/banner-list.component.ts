import { Component, OnInit } from '@angular/core';
import { BannerServiceService } from '../../services/banner-service.service';

@Component({
  selector: 'app-banner-list',
  templateUrl: './banner-list.component.html',
  styleUrls: ['./banner-list.component.css'],
})
export class BannerListComponent implements OnInit {
  banners: any[] = [];
  newBanner: any = {
    category: '',
    imageUrl: '',
    position: 0,
    visibility: true,
    link: '',
  };

  constructor(private bannerService: BannerServiceService) {}

  ngOnInit(): void {
    this.banners = this.bannerService.getBanners();
  }

  addBanner(): void {
    this.bannerService.addBanner(this.newBanner);
    this.newBanner = {
      category: '',
      imageUrl: '',
      position: 0,
      visibility: true,
      link: '',
    };
  }
}
