import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class BannerServiceService {
  private banners: any[] = [
    {
      category: 'Electronics',
      imageUrl: 'assets/banner1.jpg',
      position: 1,
      visibility: true,
      link: 'https://example.com',
    },
  ];

  getBanners(): any[] {
    console.log(this.banners);
    return this.banners;
  }

  addBanner(banner: any): void {
    this.banners.push(banner);
  }
}
