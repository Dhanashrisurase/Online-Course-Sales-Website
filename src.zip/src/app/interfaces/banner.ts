export interface Banner {
  category: string;
  imageUrl: string;
  position: number;
  visibility: boolean;
  link: string;
}
